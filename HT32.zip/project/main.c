//-----------------------------------------------------------------------------
#include "ht32.h"
#include "ht32_board.h"


//-----------------------------------------------------------------------------
int main(void)
{
	CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
	CKCUClock.Bit.AFIO = 1;
	CKCUClock.Bit.PC = 1;
	CKCU_PeripClockConfig(CKCUClock, ENABLE);

	/* Configure AFIO mode of output pins                                                                     */
	AFIO_GPxConfig(GPIO_PC, AFIO_PIN_14, AFIO_FUN_GPIO);
	AFIO_GPxConfig(GPIO_PC, AFIO_PIN_15, AFIO_FUN_GPIO);

	/* Configure GPIO direction of output pins                                                                */
	GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_14, GPIO_DIR_OUT);
	GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_15, GPIO_DIR_OUT);

	GPIO_WriteOutBits(HT_GPIOC,GPIO_PIN_14,RESET);
	GPIO_WriteOutBits(HT_GPIOC,GPIO_PIN_15,RESET);

	while(1);
}
