#ifndef __USART_H__
#define __USART_H__
#include "ht32.h"
void BLUETEETH_USART_Init(void);
#endif