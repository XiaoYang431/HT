#ifndef __PWM_H__
#define __PWM_H__
void PWM_Init(void);
void PWM_Setcompare1(uint16_t CRR);
void PWM_Setcompare2(uint16_t CRR);
void PWM_Setcompare3(uint16_t CRR);
void PWM_Setcompare4(uint16_t CRR);
#endif